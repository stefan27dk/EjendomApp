﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Dynamic;
namespace Ejendom_DB___Winforms_App
{
    class ForSell: DynamicObject
    {
        public int ResidenceID { get; set; }
        public int ResidenceSellPrice { get; set; }
        public string ResidenceAdr { get; set; }
        public int ResidenceNr { get; set; }
        public int ResidenceFloor { get; set; }
        public string ResidenceCity { get; set; }
        public int ZipCode { get; set; }
        public string ResidenceDetails { get; set; }
        public int ResidenceFloorAmount { get; set; }
        public string ResidenceSeller { get; set; }

        public string Info()
        {
            return ResidenceID.ToString().PadRight(3) + ResidenceSellPrice + "\t" + ResidenceAdr.ToString().PadRight(28) + ResidenceNr + "\t"
                        + ResidenceFloor + "\t" + ResidenceCity + "\t" + ZipCode + "\t" + ResidenceDetails + "\t" +
                        ResidenceFloorAmount + "\t" + ResidenceSeller;
        }

        public ForSell()
        {

        }
    }
}
