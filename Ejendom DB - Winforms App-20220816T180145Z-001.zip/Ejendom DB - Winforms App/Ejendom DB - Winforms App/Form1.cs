﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace Ejendom_DB___Winforms_App
{
    public partial class Form1 : Form
    {
      
        
        List<ForSell> ForSellList = new List<ForSell>();


        public Form1()
        {
            InitializeComponent();
        }

        private void MenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            menuStrip1.ForeColor = Color.FromArgb(255, 158, 54);
            checkBox1.Checked = true;
           
        
        }




  
     




        private void ReadHousesForSale()///Reader

        {
            string print;

            if (checkBox1.Checked)
            {
                print = "SELECT* FROM Residence Where ResidenceSold = 0 ";
            }

            else
            {
                print = $"SELECT* FROM Residence Where ResidenceSold = 0 And ResidenceZipCode = {PostNrtextBox.Text}";
            }

                try
            {



                using (SqlConnection connection = new SqlConnection("Data source=BG-PC\\SQLEXPRESS; Database=EjendomDB; User Id=abc; Password=abc;"))///Connection to DB

                using (SqlCommand queryItems = new SqlCommand($"{print}  ", connection))///SQL SCRIPT - Get all Houses for sell
                {
                    connection.Open();


                    using (SqlDataReader reader = queryItems.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            ForSell houseforsell = new ForSell();
                            houseforsell.ResidenceID = Convert.ToInt32(reader["ResidenceID"].ToString());
                            houseforsell.ResidenceSellPrice = Convert.ToInt32(reader["ResidenceSellPrice"].ToString());
                            houseforsell.ResidenceAdr = reader["ResidenceAdr"].ToString();
                            houseforsell.ResidenceNr = Convert.ToInt32(reader["ResidenceNr"].ToString());
                            houseforsell.ResidenceFloor = Convert.ToInt32(reader["ResidenceFloor"].ToString());
                            houseforsell.ResidenceCity = reader["ResidenceCity"].ToString();
                            houseforsell.ZipCode = Convert.ToInt32(reader["ResidenceZipCode"].ToString());
                            houseforsell.ResidenceDetails = reader["ResidenceDetails"].ToString();
                            houseforsell.ResidenceFloorAmount = Convert.ToInt32(reader["ResidenceFloorAmount"].ToString());
                            houseforsell.ResidenceSeller = reader["ResidenceSellerID"].ToString();


                            ForSellList.Add(houseforsell);

                            
                        }


                        


                        connection.Close();

                    }


                }
            }

            catch (Exception)
            {
               
            }

        }///Reader::END::

        private void SaveButton_Click(object sender, EventArgs e)
        {

            ReadHousesForSale();
          Writer();
            ForSellList.Clear();
        }

        private void Writer()
        {
            foreach (ForSell hourse in ForSellList)
            {
                System.IO.File.AppendAllText(@"C:\HousesForSell.txt", hourse.Info()+Environment.NewLine);
            }

        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)/// If checkbox checked
        {

            if (checkBox1.Checked)
            {
                PostNrtextBox.Enabled = false;
            }

            else
            {
                PostNrtextBox.Enabled = true;
            }
        }
    }
}
